from rest_framework import routers
from django.urls import path, include
from .api import get_level_from_raw_text


urlpatterns = [
    path('level/', get_level_from_raw_text),
]